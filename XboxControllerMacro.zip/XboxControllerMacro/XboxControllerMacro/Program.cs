﻿using System;
using System.Threading;
using SharpDX.XInput; // If you get an error install this NuGet package "SharpDX.XInput"

class XboxControllerMacro
{
    static void Main(string[] args)
    {
        Console.Title = "Controller macro - Made by Fenix";
        Console.WriteLine("This is a open source free use project.\n");
        Console.WriteLine("Discord = fenix.wow\n"); // Any questions (That ain't stupid.) message me on discord :>
        Console.WriteLine("Starting Controller Macro...\n");
        Controller controller = new Controller(UserIndex.One);

        while (!controller.IsConnected)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Controller not found!\nPlease connect your controller to your PC via cable or Bluetooth to use this tool.");
            Console.ResetColor();
            Thread.Sleep(5000);
        }

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Controller found!\n");
        Console.ResetColor();

        Console.WriteLine("Press the button you would like to macro.");
        GamepadButtonFlags buttonToMacro = WaitForButtonPress(controller);

        Console.WriteLine($"Button pressed: {buttonToMacro}");
        Console.WriteLine("Is this what you would like to macro? Y/N");

        if (Console.ReadLine()?.Trim().ToLower() != "y")
        {
            Console.WriteLine("Exiting... Restart the tool to select another button.");
            return;
        }

        Console.WriteLine("How fast would you like this button to be macro'd? (In ms)");
        if (!int.TryParse(Console.ReadLine(), out int interval) || interval <= 0)
        {
            Console.WriteLine("Invalid input. Exiting...");
            return;
        }

        Console.WriteLine("Done! Press and hold this button to start the macro. Release to stop.");

        while (true)
        {
            var state = controller.GetState();

            if ((state.Gamepad.Buttons & buttonToMacro) != 0)
            {
                Console.WriteLine("Macro started.");
                int pressCount = 0;

                while ((controller.GetState().Gamepad.Buttons & buttonToMacro) != 0)
                {
                    // Simulate the button press
                    Console.WriteLine("Macro action performed.");
                    pressCount++;
                    Thread.Sleep(interval);
                }

                Console.WriteLine($"Macro ended and pressed {pressCount} times.");
            }

            Thread.Sleep(50); // Avoid excessive polling
        }
    }

    private static GamepadButtonFlags WaitForButtonPress(Controller controller)
    {
        while (true)
        {
            var state = controller.GetState();

            foreach (GamepadButtonFlags button in Enum.GetValues(typeof(GamepadButtonFlags)))
            {
                if ((state.Gamepad.Buttons & button) != 0)
                {
                    return button;
                }
            }

            Thread.Sleep(50);
        }
    }
}
